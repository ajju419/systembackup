package com.ojas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="visitor")
public class VisitorEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="vid")
	private Integer vid;
	@Column(name="vname")
	private String vname;
	@Column(name="vgender")
	private String vgender;
	@Column(name="vtime")
	private String vtime;
	@Column(name="vdate")
	private String vdate;
	@Column(name="vage")
	private int vage;
	@Column(name="vaddress")
	private String vaddress;
	@Column(name="vphone")
	private long vphone;
	@Column(name="vemail")
	private String vemail;


}
