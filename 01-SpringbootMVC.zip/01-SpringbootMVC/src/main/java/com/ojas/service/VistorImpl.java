package com.ojas.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ojas.entity.VisitorEntity;
import com.ojas.model.Visitor;
import com.ojas.repository.VisitorRepo;
@Service
public class VistorImpl implements  VisitorService{
	@Autowired
private VisitorRepo vrepo;
	@Override
	public List<Visitor> visBelongToHyd(String address) {
		List<VisitorEntity> ve=vrepo.vistorsBelongToHyd(address);
		List <Visitor> visitor= new ArrayList();
		ve.forEach(v->{
			Visitor vr=new Visitor();
			BeanUtils.copyProperties(v,vr);
			visitor.add(vr);
			
		});
	
	
		
		return visitor;
	}
	@Override
	public List<Visitor> visMaleBelongToHyd(String vgender, String address) {
	
		
		List<VisitorEntity> ve=vrepo.vistorsMaleBelongToHyd(vgender,address);
		List <Visitor> visitor= new ArrayList();
		ve.forEach(v->{
			Visitor vr=new Visitor();
			BeanUtils.copyProperties(v,vr);
			visitor.add(vr);
			
		});
		return visitor;
	}
	
	@Override
	public List<Visitor> visFemaleless30(String vgender, int age) {

		List<VisitorEntity> ve=vrepo.vistorsFemaleLessthan30(vgender,age);
		List <Visitor> visitor= new ArrayList();
		ve.forEach(v->{
			Visitor vr=new Visitor();
			BeanUtils.copyProperties(v,vr);
			visitor.add(vr);
			
		});
		return visitor;
	}
	public List<Visitor> vistorsBeforeOne(String vtime) {

		List<VisitorEntity> ve=vrepo.vistorsBefore1pm( vtime);
		
		List <Visitor> visitor= new ArrayList();
		ve.forEach(v->{
			Visitor vr=new Visitor();
			BeanUtils.copyProperties(v,vr);
			visitor.add(vr);
			
		});
		return visitor;
	}
	
	public Map<String,Long> vistorTotaltime() throws Exception {

		List<VisitorEntity> ve=vrepo.totalTimeEachVistor();
		Map<String,Long> m=new HashMap<>();
		List <Visitor> visitor= new ArrayList();
		ve.forEach(v->{
			Visitor vr=new Visitor();
			BeanUtils.copyProperties(v,vr);
	String time1	=vr.getVtime();
	
	
	String time2 = "18:30:00";
	

	SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
	Date date1;
	Date date2;
	try {
		date1 = format.parse(time1);
		date2 = format.parse(time2);
		Long total = date2.getTime() - date1.getTime(); 
		long totalminutes  = total / (60 * 1000) % 60;
		long totalhours = total / (60 * 60 * 1000) % 24;
	long	timetotal=totalhours+totalminutes;
		String str=vr.getVname();
		m.put(str, totalhours);
	}catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			
		});
		return m;
	}
	
	
	
	

}
