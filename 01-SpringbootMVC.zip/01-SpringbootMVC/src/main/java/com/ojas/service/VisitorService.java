package com.ojas.service;

import java.util.List;

import com.ojas.entity.VisitorEntity;
import com.ojas.model.Visitor;

public interface VisitorService {
	public List<Visitor> visBelongToHyd(String address);
	public List<Visitor> visMaleBelongToHyd(String vgender ,String address);
	
	public List<Visitor> visFemaleless30(String vgender ,int age);
	
}
