package com.ojas.model;

import lombok.Data;

@Data
public class Visitor {
	private int vid;
	private String vname;
	private String vgender;
	private String vtime;
	private String vdate;
	private int vage;
	private String vaddress;
	private long vphone;
	private String vemail;

}
