package com.ojas.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ojas.model.Visitor;
import com.ojas.service.VistorImpl;

@Controller
public class VisitorsController {
	@Autowired 
	private VistorImpl vimpl;
	@RequestMapping(value="/getdata/{vaddress}" ,method=RequestMethod.GET)
	public String getVistorData(@PathVariable("vaddress") String  vaddress,Model model){
		List<Visitor> visitor= vimpl.visBelongToHyd(vaddress); 
		model.addAttribute("hyd", visitor);
		String msg="good morning";
		//model.addAttribute("msg", msg);
		System.out.println("controller"+visitor);
		return "index";
	}
	@GetMapping("/getdata/{vgender}/{vaddress}")
	public String getMaleVistorData(@PathVariable("vgender") String vgender,@PathVariable("vaddress") String  vaddress,Model model){
		List<Visitor> visitor= vimpl.visMaleBelongToHyd(vgender,vaddress); 
		model.addAttribute("malevisitorshyd", visitor);
		
		//model.addAttribute("msg", msg);
		
		return "index";
	}
	@GetMapping("/data/{vgender}/{age}")
	public String getFemaleVistorData(@PathVariable("vgender") String vgender,@PathVariable("age") int  age,Model model){
		List<Visitor> visitor= vimpl.visFemaleless30 (vgender,age); 
		model.addAttribute("femalelt30", visitor);
		return "index";
	}
	
	@GetMapping("/visitortime/{vtime}")
	public String getFemaleVistorData(@PathVariable("vtime") String vtime,Model model){
		List<Visitor> visitor= vimpl.vistorsBeforeOne(vtime); 
		model.addAttribute("vistorsbeforeonepm", visitor);
		return "index";
	}
	@GetMapping("/calculatetime")
	public String calculateTime(Model model) throws Exception{
		Map<String,Long> visitor= vimpl.vistorTotaltime(); 
		model.addAttribute("calculatetime", visitor);
		return "index";
	}
	
	
}

