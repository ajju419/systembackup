package com.ojas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ojas.entity.VisitorEntity;


@Repository
public interface VisitorRepo extends JpaRepository<VisitorEntity ,Integer>{
	@Query(value="select * from visitor where vaddress=?1",nativeQuery=true)
public List<VisitorEntity> vistorsBelongToHyd(String address);
	
	@Query(value="select * from visitor where vgender=?1 and vaddress=?2",nativeQuery=true)
	public List<VisitorEntity> vistorsMaleBelongToHyd(String vgender, String address);
		
	@Query(value="select * from visitor where vgender=?1 and vage<?2",nativeQuery=true)
	public List<VisitorEntity> vistorsFemaleLessthan30(String vgender, int vage);
	@Query(value="select * from visitor where vtime<?1",nativeQuery=true)
	public List<VisitorEntity> vistorsBefore1pm(String vtime);
	@Query(value="select * from visitor",nativeQuery=true)
	public List<VisitorEntity> totalTimeEachVistor();
	
	
}
