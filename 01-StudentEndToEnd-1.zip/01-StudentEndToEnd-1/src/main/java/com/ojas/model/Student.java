package com.ojas.model;

public class Student {

	private int sid;
	private String sname;
	private int smarks;
	private int sage;
	private char sgrade;
	private String sresult;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getSmarks() {
		return smarks;
	}

	public void setSmarks(int smarks) {
		this.smarks = smarks;
	}

	public int getSage() {
		return sage;
	}

	public void setSage(int sage) {
		this.sage = sage;
	}

	public char getSgrade() {
		return sgrade;
	}

	public void setSgrade(char sgrade) {
		this.sgrade = sgrade;
	}

	public String getSresult() {
		return sresult;
	}

	public void setSresult(String sresult) {
		this.sresult = sresult;
	}

}
