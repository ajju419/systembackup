package Exercise_3;

public class First10NaturalNumbers {

	public static void main(String[] args) {
		int i;
		System.out.println ("The first 10 natural numbers are:\n");
		for (i=1;i<=10;i++)
		{      
			System.out.println (i);
		}
	System.out.println ("\n");
	}
}
